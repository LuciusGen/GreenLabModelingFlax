%T__Tm__N____W__kW__b___bf___rnd__msk_param_dev.
31	19	1	1	1	1	1	3	1	1
%na__np__ni_nc__nf__nm__nt_xx_xx_xx_nb_0rg/Phyt
1	1	1	0	1	1	0	0	0	2
%tfa__tfp__tfi__tfc_tff__tfm_tft_tw__xx_org_funct.duration
20	0	0	0	0	0	0	99	0	3
%txa__txp__txi__txc_txf__txm_txt_xx_xx_org_expan.duration
12	12	30	0	30	2	99	0	0	4
%txo_n_ctl_step1_step2_step3_step4_control_expantion_steps
3	1	6	12	0	0	0	0	0	5
%step1(a___p___i___f___m)_xx_xx_xx_xx_%of_expansion_time
0.33	0.33	0.08	1	1	1	1	0	0	6
%step2(a___p___i___f___m)_xx_xx_xx_xx_of_expansion_time
0.66	0.66	0.25	1	1	1	1	0	0	7
%step3(a___p___i___f___m)_xx_xx_xx_xx_)_%of_expansion_time
1	1	1	1	1	1	1	0	0	8
%step4(a___p___i___f___m)_xx_xx_xx_xx__%of_expansion_time
1	1	1	1	1	1	1	0	0	9
%pa__pp____pi___pc__pf_pm__pt__pq_xx_sink_orgam_strenght
1	0.909474	2.54272	0	2360.56	4.22134	0	0	0	10
%kpc_kpa_kpi_mna_ca_mnp_cp_mni_ci%special_sink_param
0	0	0	0	0	0	0	0	0	11
%_void_
0	0	0	0	0	0	0	0	0	12
%Ba(_a____p___i__c__f___m__t)_xx_xx_param1_sink_variation_betalaw
2.71306	2.16624	4.0875	0	7.34243	1	1	0	0	13
%Bb(_a___p___i___c___f___m__t)_xx_xx_param2_Beta
3.84641	3.81235	7.0254	0	4.77053	2	1	0	0	14
%DL(_a___p___i___c__f___m__t)_xx_xx_expansion_delay
0	2	0	0	3	0	0	0	0	15
%e____b1____a1__f1_sQo__sSp___allometry_leaf_internode_fruit
0.024	10	0	0.5	0	0	0	0	0	16
%E__Qo__aQo__aQr__r___Sp__kc_xx_xx_%functioning_prameters
1	1.08992	1	0	18.0113	1190.99	1	0	0	17
%comp__phyt__settings_Glsqr
1	1	0	0	0	0	0	0	0	18
%xQo_xaQo_xr_xSp_xpp_xpi_xpc_xpf_xpm_chosing_params
1	0	1	1	1	1	0	1	1	19
%xpt_kpc_kpa_kpi_x_14_x_15_x_16x_17_x_18sinks
0	0	0	0	0	0	0	0	0	20
%sQo_sSp_x_21_x_22_x_23_x_24_xBa1_xBp1_xBi1_expanlaw_chosing_params
0	0	0	0	0	0	1	1	1	21
%xBf1_xBm1_xBt1_xBa2_xBp2_xBi2_xBf2_xBm2_xBt2___expansionlaw
1	0	0	0	0	0	0	0	0	22
%modE__Eo___cor_wE__bE__Lmax_Lmin_Lightparam
1	0	0	0	0	0	0	0	0	23
%modH_c1___c2___Hmx_Hmn_H1_psi__pH20_dH20_Hydroparam
0	0	0	0	0	0	0	0	0	24
